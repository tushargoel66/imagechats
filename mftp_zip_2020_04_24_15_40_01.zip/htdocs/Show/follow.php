<?php
        session_start();
        $con=mysqli_connect('sql201.epizy.com','epiz_25483150','kjwdX0hGFKpB','epiz_25483150_data');
        $us=$_SESSION['user'];
        $s=$_POST['user'];
        $q="insert into follower values('$s','$us')";
        $res=mysqli_query($con,$q);
?>