<?php
session_start();
if(!isset($_SESSION['user'])){
  header( 'location:\index2.html' );
}

?>
<!doctype html>
<html lang="en">
<head>
    <style type="text/css">
        #txt{
            opacity: .5;
            border: 0px;
        }
    </style>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.13.0/css/mdb.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="/Image/logo.png"/>
    
    <!--script>
$(document).ready(function(){
	setInterval(function(){
		$("#xy").load('/image.php')
    }, 1000);
});
</script-->
    <style type="text/css">
.thumb-image{
 float:left;width:150px;
 position:relative;
 padding:5px;
}
</style>
    <title><?php session_start(); $u=$_SESSION['user']; echo $u;?></title>
</head>

   

<body style="background-image: url('bg5.jpg');">
    <nav class="navbar navbar-expand-lg navbar navbar-dark " >
        <div style="padding-left:150px;">
        
        <a class="navbar-brand" href="/home.php"> &nbsp; ChatBook</a>
        </div>
<div style="padding-left:300px;">
<form class="form-inline">
  <i class="fas fa-search" aria-hidden="true"></i>&nbsp;&nbsp;
  <input type="text" placeholder="Search a Friend..." onkeyup="search(this.value)" id="txt" aria-label="Search" style="width:200px;" autocomplete="off">
  
</form>
 </div>


<script>
    function search(c){
        if(c.length!=0){
            jQuery.ajax({
                url:'search.php',
                type:'post',
                data: 'id='+c,
                success:function(result){
                    jQuery('#search_result').html(result);
                }
            });
        }
        else{
            jQuery('#search_result').html("");
        }
    }
</script>

<script>
    function user(name){
        window.location.href="/otherprofile.php?user=" +name;
    }
</script>


        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">         
            <li class="nav-item dropdown">
            
            
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="margin-left:60px;">
          Welcome &nbsp; <font color="black"><?php session_start();  echo $_SESSION['user']; ?></font>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="\profile.php">Profile</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="\peopleyoumayknow.php">Find Friends</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="\Login\logout.php">Logout</a>
        </div>
      </li>
          </ul>
        </div>
          </ul>
        </div>
      </nav>
    <div id="search_result">
  
  </div>




    <div style="padding-left:10px;padding-top:10px;">
    <div class="container">
    <div class="row">
    <div class="col-lg-">

        <div class="card" style="padding-left:20px;width:800px;background:rgba(255,255,255,.5);color:black;">
   <div class="card-body">
   <h4 class="class-title">People You may know...<hr><br><br></h4>
    <?php
        session_start();
        $con=mysqli_connect('sql201.epizy.com','epiz_25483150','kjwdX0hGFKpB','epiz_25483150_data');
        $us=$_SESSION['user'];
        $q="select * from information where Username <> '$us'";
        $res=mysqli_query($con,$q);
        $i=0;
        while($row=mysqli_fetch_assoc($res)){
            $u=$row['Username'];
            $res1=mysqli_query($con,"select Username from follower where Follower = '$us'");
            $status=0;
            while($row1=mysqli_fetch_assoc($res1)){
                if($row1['Username']==$u){
                    $status=1;
                    break;
                }
            }
            if($status==0){
                if($row['Dp']==null){
                    if($row['Gender']=='M'||$row['Gender']=='m'){
                        echo '<img src="\Image\male.png" alt="Avatar" class="rounded-circle" class="avatar" width="70" height="70"><font size="4">&nbsp;&nbsp;&nbsp;&nbsp;'.$row['Name'].'</font>';
                   echo '<a class="btn btn-info fa fa-thumbs-o-up like btn float-right" href=javascript:void(0) onclick="count(\''.$row['Username'].'\')"><span id="lk_'.$row['Username'].'"><b>Follow</b></a><br><hr></span></a>';
                    }
                    else{
                        echo '<img src="\Image\female.png" alt="Avatar" class="rounded-circle" class="avatar" width="70" height="70"><font size="4">&nbsp;&nbsp;&nbsp;&nbsp;'.$row['Name'].'</font>';
                    echo '<a class="btn btn-info fa fa-thumbs-o-up like btn float-right" href=javascript:void(0) onclick="count(\''.$row['Username'].'\')"><span id="lk_'.$row['Username'].'"><b>Follow</b></a><br><hr></span></a>';
                    }
                        
                }
                else{
                    echo '<img src="'.$row['Dp'].'" alt="Avatar" class="rounded-circle" class="avatar" width="70" height="70"><font size="4">&nbsp;&nbsp;&nbsp;&nbsp;'.$row['Name'].'</font>';
                    echo '<a class="btn btn-info fa fa-thumbs-o-up like btn float-right" href=javascript:void(0) onclick="count(\''.$row['Username'].'\')"><span id="lk_'.$row['Username'].'"><b>Follow</b></a><br><hr></span></a>';
                }
            }
        }
    ?>
    
    <div style="padding-bottom:30px;"></div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>


<script>
    function count(user){
        
        jQuery.ajax({
            url:'follow.php',
            type:'post',
            data: 'user='+user,
            success:function(result){
                jQuery('#lk_'+user).html("Following");
            }
        });
    }
</script>
    
    <!-- JQuery -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.13.0/js/mdb.min.js"></script>
</body>
</html>