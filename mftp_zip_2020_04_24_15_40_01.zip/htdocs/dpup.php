<?php
            session_start();
            $con=mysqli_connect('sql201.epizy.com','epiz_25483150','kjwdX0hGFKpB','epiz_25483150_data');
            $us=$_SESSION['user'];
            $im=$_POST['img'];
            $ext = strtolower(pathinfo($_FILES['img']['name'], PATHINFO_EXTENSION));            
           //Convert image to base64
           $encoded_image = base64_encode(file_get_contents($_FILES['img']['tmp_name']));
           $encoded_image = 'data:image/jpeg' . $ext . ';base64,' . $encoded_image;
            $q="UPDATE information SET Dp='$encoded_image' WHERE Username='$us'";
            $res=mysqli_query($con,$q);
            //echo '<img src="data:image/;base64,'.base64_encode($encoded_image).'"height="300" width="470"/>';
            header('location:/profile.php');
?>