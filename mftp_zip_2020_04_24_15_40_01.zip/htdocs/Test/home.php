
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.13.0/css/mdb.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="/Image/logo.png"/>
    <!--script>
$(document).ready(function(){
	setInterval(function(){
		$("#xy").load('/image.php')
    }, 1000);
});
</script-->
    <style type="text/css">
.thumb-image{
 float:left;width:150px;
 position:relative;
 padding:5px;
}
</style>
    <title>Home</title>
</head>

   

<body style="background-color:rgb(200,210,240) ">
    <nav class="navbar navbar-expand-lg navbar navbar-dark bg-success" >
        <div style="padding-left:150px;">
        <img src="/Image/logo.png" class="rounded-circle" alt="Cinque Terre" height="30">
        <a class="navbar-brand" href="/home.php"> &nbsp; ImageChat</a>
        </div>
<div style="padding-left:300px;">
<form class="form-inline">
  <i class="fas fa-search" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <input type="text" placeholder="Search" onkeyup="search(this.value)" id="txt" aria-label="Search">
  <div id="search_result">
  
  </div>
</form>
 </div>


<script>
    function search(c){
        jQuery.ajax({
            url:'search.php',
            type:'post',
            data: 'id='+c,
            success:function(result){
                jQuery('#search_result').html(result);
            }
        });
    }
</script>




        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">         
            <li class="nav-item dropdown">
            
            
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="margin-left:60px;">
          Welcome &nbsp; <font color="black"><?php session_start();  echo $_SESSION['user']; ?></font>
        </a>
         
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="\profile.php">Profile</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="\peopleyoumayknow.php">Find Friends</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="\Login\logout.php">Logout</a>
        </div>
      </li>
          </ul>
        </div>
          </ul>
        </div>
       
      </nav>

    <div class="container">
        <div class="row"style="width:1200px;">
        <div class="col-lg-" style="padding-top:25px;">
        <div class="card"style="width:200px;padding-bottom:10px;">
      <div class="card-body">
      <h6 class="card-title">Whats in your mind?<hr></h6>
      <form action="uploadtxt.php" method="post">
    <input type="text" name="message" placeholder="Whats on your mind?" style="height:45px;width:160px;border:2px black solid;"><br><br>
    <div><center><input type="submit" value="Post" name="submit"></center></div>
    </form>
      </div>
      </div>
      </div>




        <div style="padding-left:15px;">
      <div class="col-lg-"style="padding-top:25px;">
      <div class="card bg-dark" style="width:550px" >
      <div class="card-body">
        
        <?php
            session_start();
            $con=mysqli_connect('sql201.epizy.com','epiz_25483150','kjwdX0hGFKpB','epiz_25483150_data');
            $us=$_SESSION['user'];
            $q="select * from image order by id desc";
            $res=mysqli_query($con,$q);
            while($row=mysqli_fetch_assoc($res)){
                $u=$row['Username'];
                $q1="select * from information where Username='$u'";
                $res1=mysqli_query($con,$q1);
                $row1 = mysqli_fetch_array($res1, MYSQLI_ASSOC);
                //$row2=mysqli_fetch_array($res2, MYSQLI_ASSOC);
                $status=0;
                $res2=mysqli_query($con,"select Username from follower where Follower='$us'");
                while($row2=mysqli_fetch_assoc($res2)){
                    if($row2['Username']==$u){
                        $status=1;
                        break;
                    }
                }
                if($status==1||$u==$us)
                if($row['Image']!=null){
                    if($row['Caption']==null){
                        if($row1['Dp']!=null){
                            echo '<div class="card"style="width:505px"><div class="card-body">';
                            echo '<div class="card-header"><img src="'.($row1['Dp'] ).'"class="rounded-circle "height="40" width="40"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$row['Username'].'</div><br><br>';
                            echo '<img src="'.($row['Image'] ).'"height="300" width="465"/><br>';
                            echo '<div class="card-footer text-muted"><font size="1"><b>'.$row['Time'].'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$row['Date'].'</font></b></div>';
                            echo '</div><a class="btn btn-info fa fa-thumbs-o-up like btn" href=javascript:void(0) onclick="count('.$row['Id'].')"><b>Like &nbsp;&nbsp;&nbsp;<span id="lk_'.$row['Id'].'">'.$row['Likes'].'</b></a></span></div>';
                            echo '<div style="padding-bottom:20px;"></div>';
                        }
                        else{
                            echo '<div class="card"style="width:505px"><div class="card-body">';
                            echo '<div class="card-header"><img src="/Image/male.png"class="rounded-circle "height="40" width="40"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$row['Username'].'</div><br><br>';
                            echo '<img src="'.($row['Image'] ).'"height="300" width="465"/><br>';
                            echo '<div class="card-footer text-muted"><font size="1"><b>'.$row['Time'].'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$row['Date'].'</font></b></div>';
                            echo '</div><a class="btn btn-info fa fa-thumbs-o-up like btn" href=javascript:void(0) onclick="count('.$row['Id'].')"><b>Like &nbsp;&nbsp;&nbsp;<span id="lk_'.$row['Id'].'">'.$row['Likes'].'</b></a></span></div>';
                            echo '<div style="padding-bottom:20px;"></div>';
                        }
                    }
                    else{
                        if($row1['Dp']!=null){
                            echo '<div class="card"style="width:505px"><div class="card-body">';
                            echo '<div class="card-header"><br><img src="'.($row1['Dp'] ).'"class="rounded-circle "height="40" width="40"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$row['Username'].'</div><br>';
                            echo '<font size="3">'.$row['Caption'].'</font><br>';
                            echo '<img src="'.($row['Image'] ).'"height="300" width="465"/><br>';
                            echo '<div class="card-footer text-muted"><font size="1"><b>'.$row['Time'].'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$row['Date'].'</font></b></div>';
                            echo '</div><a class="btn btn-info fa fa-thumbs-o-up like btn" href=javascript:void(0) onclick="count('.$row['Id'].')"><b>Like &nbsp;&nbsp;&nbsp;<span id="lk_'.$row['Id'].'">'.$row['Likes'].'</b></a></span></div>';
                            echo '<div style="padding-bottom:10px;"></div>';
                        }
                        else{
                            echo '<div class="card"style="width:505px"><div class="card-body">';
                            echo '<div class="card-header"><br><img src="/Image/male.png"class="rounded-circle "height="40" width="40"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$row['Username'].'</div><br>';
                            echo '<font size="3">'.$row['Caption'].'</font><br>';
                            echo '<img src="'.($row['Image'] ).'"height="300" width="465"/><br>';
                            echo '<div class="card-footer text-muted"><font size="1"><b>'.$row['Time'].'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$row['Date'].'</font></b></div>';
                            echo '</div><a class="btn btn-info fa fa-thumbs-o-up like btn" href=javascript:void(0) onclick="count('.$row['Id'].')"><b>Like &nbsp;&nbsp;&nbsp;<span id="lk_'.$row['Id'].'">'.$row['Likes'].'</b></a></span></div>';
                            echo '<div style="padding-bottom:10px;"></div>';
                        }
                    }
                }
                else{
                    if($row1['Dp']!=null){
                        echo '<div class="card"style="width:505px"><div class="card-body">';
                        echo '<div class="card-header"><img src="'.($row1['Dp'] ).'"class="rounded-circle "height="40" width="40"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$row['Username'].'</div><br><br>';
                        echo '<div>'.$row['Caption'] .'</div><br><br>';
                        echo '<div class="card-footer text-muted"><font size="1"><b>'.$row['Time'].'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$row['Date'].'</font></b></div>';
                        echo '</div><a class="btn btn-info fa fa-thumbs-o-up like btn" href=javascript:void(0) onclick="count('.$row['Id'].')"><b>Like &nbsp;&nbsp;&nbsp;<span id="lk_'.$row['Id'].'">'.$row['Likes'].'</b></a></span></div>';
                        echo '<div style="padding-bottom:20px;"></div>';
                    }
                    else{
                        echo '<div class="card"style="width:505px"><div class="card-body">';
                        echo '<div class="card-header"><img src="/Image/male.png"class="rounded-circle "height="40" width="40"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$row['Username'].'</div><br><br>';
                        echo '<div>'.$row['Caption'] .'</div><br><br>';
                        echo '<div class="card-footer text-muted"><font size="1"><b>'.$row['Time'].'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$row['Date'].'</font></b></div>';
                        echo '</div><a class="btn btn-info fa fa-thumbs-o-up like btn" href=javascript:void(0) onclick="count('.$row['Id'].')"><b>Like &nbsp;&nbsp;&nbsp;<span id="lk_'.$row['Id'].'">'.$row['Likes'].'</b></a></span></div>';
                        echo '<div style="padding-bottom:20px;"></div>';
                    }
                }
            }
        ?>
        </div>
        </div>
        
            </div>
            </div>
            
        <div style="padding-left:15px;">
        <div class="col-lg-" style="padding-top:25px;">
        <div class="card"style="padding-bottom:50px;width:360px;">
      <div class="card-body">
      <h5 class="card-title">Post a memory..<hr></h5>
      <form action="upload.php" method="post" enctype="multipart/form-data">
    <input type="text" name="text" placeholder="Caption" style="height:60px;width:320px;border:2px black solid;"><br>
    
    <br><br>
    <input type="file" name="img" id="img" accept="image/*"><br><br>
    
    <div id="image-holder"></div><br><br>
    
    <script>
$(document).ready(function() {
        $("#img").on('change', function() {
          //Get count of selected files
          var countFiles = $(this)[0].files.length;
          var imgPath = $(this)[0].value;
          var extn = imgPath.substring(imgPath.lastIndexOf('.') + 1).toLowerCase();
          var image_holder = $("#image-holder");
          image_holder.empty();
          if (extn == "gif" || extn == "png" || extn == "jpg" || extn == "jpeg") {
            if (typeof(FileReader) != "undefined") {
              //loop for each file selected for uploaded.
              for (var i = 0; i < countFiles; i++) 
              {
                var reader = new FileReader();
                reader.onload = function(e) {
                  $("<img />", {
                    "src": e.target.result,
                    "class": "thumb-image"
                  }).appendTo(image_holder);
                }
                image_holder.show();
                reader.readAsDataURL($(this)[0].files[i]);
              }
            } else {
              alert("This browser does not support FileReader.");
            }
          } else {
            alert("Pls select only images");
          }
        });
      });
</script>
<div><center><input type="submit" value="Post" name="submit"></center></div><br><br>
Please use a PC to upload picture 
</form>
      </div>
      </div>

 <div style="padding-top:25px;"></div>


      <div class="card"style="padding-bottom:300px;width:360px;">
      
      <div class="card-body">
      <h5 class="card-title">Active Friends<hr></h5>
            <?php
            session_start();
            $user=$_SESSION['user'];
            $con=mysqli_connect('sql201.epizy.com','epiz_25483150','kjwdX0hGFKpB','epiz_25483150_data');
            $s="select * from information where Username <> '$user'";            
            $res=mysqli_query($con,$s);
            while($row = mysqli_fetch_assoc($res)){
                $u=$row['Username'];
                $status=0;
                $res2=mysqli_query($con,"select Username from follower where Follower='$user'");
                while($row2=mysqli_fetch_assoc($res2)){
                    if($row2['Username']==$u){
                        $status=1;
                        break;
                    }
                }
                if($status==1){
                    if($row['OnlineStatus']==1){
                        echo '<svg height="20" width="20"><circle cx="10" cy="10" r="6"  fill="green" /></svg>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$row['Username'].'<br><br>';
                    }
                    else{
                        echo '<svg height="20" width="20"><circle cx="10" cy="10" r="6"  fill="grey" /></svg>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$row['Username'].'<br><br>';
                    }
                }
            }
          ?>
      </div>
      </div>
      
      </div>
  </div>
</div>
</div>

</div>

        <script>
                function count(id){
                    var c=jQuery('#lk_'+id).html();
                    c++;
                    jQuery('#lk_'+id).html(c);
                    jQuery.ajax({
                        url:'update.php',
                        type:'post',
                        data: 'id='+id,
                        success:function(result){
                            
                        }
                    });
                }
        </script>




    <div style="padding-bottom:10px;"></div>
    <!-- JQuery -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.13.0/js/mdb.min.js"></script>
</body>
</html>