<?php
            session_start();
            $con=mysqli_connect('sql201.epizy.com','epiz_25483150','kjwdX0hGFKpB','epiz_25483150_data');
            $us=$_SESSION['user'];
            $q="select * from image,follower where follower.Username='$us'||follower.Fuser='$us' order by image.Time desc";
            $res=mysqli_query($con,$q);
            while($row=mysqli_fetch_assoc($res)){
                //$_SESSION["img"]=$row['Image'];
                echo '<div class="card"><div class="card-body">';
                echo '<div class="card-header">'.$row['Username'].'</div>';
                echo '<img src="'.($row['Image'] ).'"height="300" width="470"/>';
                echo '<div class="card-footer text-muted"><font size="1">'.$row['Date'].'&nbsp;&nbsp;&nbsp;'.$row['Time'].'</font></div>';
                echo '</div><a class="nav-link" href="#"><b>Like</b></a></div>';
                echo '<div style="padding-bottom:10px;"></div>';
            }
?>