<?php
    session_start();
    $user=$_SESSION['user'];
    $con=mysqli_connect('sql201.epizy.com','epiz_25483150','kjwdX0hGFKpB','epiz_25483150_data');
    $id=$_POST['id'];
    $re="select Likes from image where Id=$id";
    $res=mysqli_query($con,$re);
    while($row=mysqli_fetch_assoc($res)){
        $count=$row['Likes'];
    }
    $count=$count+1;
    $r="update image set Likes=$count where Id=$id";
    mysqli_query($con,$r);
?>
