<?php
session_start();
$user=$_SESSION['user'];
$con=mysqli_connect('sql201.epizy.com','epiz_25483150','kjwdX0hGFKpB','epiz_25483150_data');
$s1="update information set OnlineStatus='0' where UserName='$user'";
mysqli_query($con,$s1);
session_destroy();

header('refresh:.01;url=\index2.html');
?>