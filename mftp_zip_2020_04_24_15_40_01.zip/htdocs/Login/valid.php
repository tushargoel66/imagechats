<?php
session_start();

 $con=mysqli_connect('sql201.epizy.com','epiz_25483150','kjwdX0hGFKpB','epiz_25483150_data');
$name=$_POST["user"];
$pass=$_POST["password"];
$pass=md5($pass);
$s="select * from information where Username='$name'||Email='$name'&& Password='$pass'";
$s1="update information set OnlineStatus='1' where UserName='$name'";
mysqli_query($con,$s1);
$result=mysqli_query($con,$s);
$num=mysqli_num_rows($result);
if($num==1){
    $_SESSION["user"]=$name;
   echo '<script type="text/javascript">
          window.onload = function () { alert("Welcome!!!!"); }
          </script>';
    
    header( 'refresh:.01;url=\home.php' );
}
else{
echo '<script type="text/javascript">
          window.onload = function () { alert("Enter a correct UserName or Password!!!!"); }
          </script>';
    
    header( 'refresh:.01;url=\index2.html' );
}
?>
