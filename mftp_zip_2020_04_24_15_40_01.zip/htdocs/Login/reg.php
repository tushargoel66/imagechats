<?php
session_start();
$con=mysqli_connect('sql201.epizy.com','epiz_25483150','kjwdX0hGFKpB','epiz_25483150_data');
//echo $con;
$nam=$_POST["name"];
$usr=$_POST["user"];
$pho=$_POST["phone"];
$pass=$_POST["password"];
$mail=$_POST["mail"];
$dob=$_POST["dob"];
$gen=$_POST["gender"];
$s="select * from information where UserName='$usr' ";
$pass=md5($pass);
$result=mysqli_query($con,$s);
$num=mysqli_num_rows($result);
echo $gen;
if($num==1){
    echo '<script type="text/javascript">
          window.onload = function () { alert("UserName already taken please choose another!!!"); }
          </script>';
    
    header( 'refresh:5;url=\Login\signup.html' );
}
else{
    $regi="insert into information values('$usr','$pass','$mail','$gen','$pho','','$nam','$dob','','')";
    mysqli_query($con,$regi);
    echo '<script type="text/javascript">
          window.onload = function () { alert("Sucessfully registered!!!"); }
          </script>';
    header( 'refresh:.01;url=\index2.html' );
}
?>