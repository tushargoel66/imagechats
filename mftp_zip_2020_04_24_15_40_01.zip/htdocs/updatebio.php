<?php
    session_start();
    $user=$_SESSION['user'];
    $con=mysqli_connect('sql201.epizy.com','epiz_25483150','kjwdX0hGFKpB','epiz_25483150_data');
    $i=$_POST['txt'];
    $r="UPDATE information SET Bio='$i' WHERE Username='$user'";
    echo $r;
    mysqli_query($con,$r);
    header('location:/profile.php');
?>
