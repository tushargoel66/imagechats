<?php
    session_start();
    $con=mysqli_connect('sql201.epizy.com','epiz_25483150','kjwdX0hGFKpB','epiz_25483150_data');
    $u=$_SESSION['user'];
    $text=$_POST['id'];
    $q="select Name,Username from information where Username like '$text%' || Name like '$text%'";
    //echo $q;
    $res=mysqli_query($con,$q);
    $output='<ul class="list" style="padding-left:580px;">';
    if(mysqli_num_rows($res)>0){
        while($row=mysqli_fetch_assoc($res)){
            if($u!=$row['Username'])
                $output .='<li class="list-group-item" style="width:220px;"><a class="nav-link" href="javascript:void(0)" onclick=user(\''.$row['Username'].'\')>'.$row['Name'].'</li></a>';
        }
    }
    else{
        $output .='<li class="list-group-item " style="width:220px;">No user with such name</li>';
    }
    $output .='</ul';
    echo $output;
?>
