<?php
            session_start();
            $con=mysqli_connect('sql201.epizy.com','epiz_25483150','kjwdX0hGFKpB','epiz_25483150_data');
            $us=$_SESSION['user'];
            $im=$_POST['img'];
            date_default_timezone_set("Asia/Calcutta");
            $time=date("H:i:s");
            $date=date("Y/m/d");
            $caption=$_POST['text'];
            $s="select Id from image";
            $r=mysqli_query($con,$s);
            $g=0;
            while($ro=mysqli_fetch_assoc($r)){
                if($g<$ro['Id'])
                    $g=$ro['Id'];
            }
            $g=$g+1;
            if($im==null){
                //echo 4444443;
                $q="INSERT INTO image VALUES('$g','$us','','$caption','$time','$date','')";
                $res=mysqli_query($con,$q);
                header('location:/home.php');
            }
            $ext = strtolower(pathinfo($_FILES['img']['name'], PATHINFO_EXTENSION));            
           //Convert image to base64
           $encoded_image = base64_encode(file_get_contents($_FILES['img']['tmp_name']));
           $encoded_image = 'data:image/jpeg' . $ext . ';base64,' . $encoded_image;
            $q="INSERT INTO image VALUES('$g','$us','$encoded_image','$caption','$time','$date','')";
            $res=mysqli_query($con,$q);
            //echo '<img src="data:image/;base64,'.base64_encode($encoded_image).'"height="300" width="470"/>';
            header('location:/home.php');
?>